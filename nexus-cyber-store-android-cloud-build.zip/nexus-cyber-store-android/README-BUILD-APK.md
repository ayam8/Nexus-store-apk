# Nexus Cyber Store Android wrapper

Project Android Studio (Kotlin + WebView) untuk membuka frontend Nexus Cyber Store dari server HTTPS.

## Wajib sebelum build
1. Deploy folder `nexus-cyber-store` (Node.js backend + frontend) ke VPS/hosting.
2. Pasang domain dan HTTPS yang valid.
3. Edit `app/src/main/java/com/nexus/cyberstore/MainActivity.kt`, ganti `https://your-domain.example` dengan URL toko milikmu.
4. Jangan memasukkan PTLA, Hostinger API token, QRIS secret, atau ADMIN_TOKEN ke APK. Simpan semuanya di `.env` backend.

## Build APK
1. Buka folder `nexus-cyber-store-android` menggunakan Android Studio.
2. Izinkan Gradle Sync dan instal Android SDK Platform 35 jika diminta.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug muncul di `app/build/outputs/apk/debug/app-debug.apk`.
5. Untuk distribusi, gunakan **Build > Generate Signed Bundle / APK > APK** dan buat keystore sendiri. Simpan keystore dengan aman.

Aplikasi ini adalah wrapper WebView. Ia memerlukan server HTTPS aktif untuk memuat toko dan API.
