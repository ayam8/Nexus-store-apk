# Build APK hanya dengan HP (GitHub Actions)

1. Ekstrak ZIP ini di HP.
2. Buat akun GitHub atau masuk ke https://github.com.
3. Di GitHub, buat repository baru (mis. `nexus-cyber-store`).
4. Upload **isi folder** `nexus-cyber-store-android` ke repository, termasuk folder tersembunyi `.github/workflows/android.yml`. Jika upload lewat browser HP tidak menampilkan folder tersembunyi, buat folder/file tersebut langsung di GitHub dengan path `.github/workflows/android.yml`, lalu salin isi workflow dari ZIP.
5. Buka tab **Actions** pada repository. Pilih **Build Nexus Cyber Store APK**, tekan **Run workflow**.
6. Tunggu sampai workflow selesai dengan status hijau. Buka run tersebut, bagian **Artifacts**, lalu unduh `NexusCyberStore-debug-apk`.
7. Ekstrak ZIP artifact dan instal `app-debug.apk` di Android. Jika diminta, izinkan instalasi dari sumber tersebut.

## Penting
- APK saat ini adalah wadah WebView. Ubah `storeUrl` di `app/src/main/java/com/nexus/cyberstore/MainActivity.kt` menjadi alamat HTTPS frontend toko yang benar sebelum build.
- Backend dan transaksi live belum otomatis aktif hanya dengan build APK. Deploy backend dan konfigurasi API provider QRIS, Hostinger, dan Pterodactyl secara terpisah. Jangan taruh API key di aplikasi Android atau repository publik.
- APK debug untuk uji coba; distribusi publik sebaiknya menggunakan release build bertanda tangan.
